<div>

        <ul>
            {{dd($vehicleString)}}
   
      </ul>
</div>