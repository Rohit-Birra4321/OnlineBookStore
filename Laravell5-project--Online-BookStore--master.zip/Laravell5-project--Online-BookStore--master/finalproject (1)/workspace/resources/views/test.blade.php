@foreach($items as $item)
{{$item}}
@endforeach