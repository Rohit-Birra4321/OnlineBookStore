@extends('layouts.master')
@section('content')
<h2>bookdetails </h2>
@endsection